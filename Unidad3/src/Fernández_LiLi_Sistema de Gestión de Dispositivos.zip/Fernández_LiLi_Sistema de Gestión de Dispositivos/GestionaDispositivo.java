package Fernández_LiLi_prueba;

public class GestionaDispositivo {

	public static void main(String[] args) {
		Smartphone smartphone = new Smartphone("Samsung", "Galaxy S21", 900, false, 2);
		Laptop laptop = new Laptop ("hP", "Android", 800, 400, 0);
		pcSobremesa pcsobremesa = new pcSobremesa ("Apple", null, 1000, 400, false);

	}

}
