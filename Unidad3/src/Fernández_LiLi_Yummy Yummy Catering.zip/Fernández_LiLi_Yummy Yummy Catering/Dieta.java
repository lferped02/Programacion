package Fernández_LiLi_prueba2;

public enum Dieta {
	VEGETARIANO, VEGANO, SIN_GLUTEN, SIN_LACTOSA;

}

