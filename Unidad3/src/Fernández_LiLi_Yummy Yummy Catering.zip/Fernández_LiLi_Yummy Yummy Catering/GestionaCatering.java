package Fernández_LiLi_prueba2;

public class GestionaCatering {

	public static void main(String[] args) {
		Menu jueves = new Menu(1, "Febrero", "Geggies", "VEGANO", null);
	}
}
